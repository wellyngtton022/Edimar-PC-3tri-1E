WELLYNGTTON VINICIUS MAIER N34  &  REBECA PEREIRA N26    

A vida é uns deveres que nós trouxemos para fazer em casa.

Quando se vê, já são 6 horas: há tempo…
Quando se vê, já é 6ª-feira…
Quando se vê, passaram 60 anos!
Agora, é tarde demais para ser reprovado…
E se me dessem – um dia – uma outra oportunidade,
eu nem olhava o relógio
seguia sempre em frente…

E iria jogando pelo caminho a casca dourada e inútil das horas.

link do poema
https://www.culturagenial.com/poemas-sobre-a-vida-escritos-por-autores-famosos
@lizibugalski

![Isso é uma imagem](https://www.guiadebemestar.com.br/wp-content/uploads/2021/02/pHX-vu8-0-relogio-de-bolso-jiyeon-park-oshg1llsna4-unsplash-scaled-1024x576.jpg)
